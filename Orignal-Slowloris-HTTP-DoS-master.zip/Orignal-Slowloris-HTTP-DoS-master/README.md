# Orignal-Slowloris-HTTP-DoS
Since http://ha.ckers.org/slowloris/ has been taken offline I will upload the original script here. 
