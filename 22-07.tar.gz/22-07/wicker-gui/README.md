**Wicker** `the wifi hacker`

<img src=https://akr3ch.github.io/wicker/wicker.png>

`this is an automated GUI based wifi hacking tool or just a shell script:D`

`whatever it might can save your expensive time to become wasted`

`automate your wifi hacking with wicker-gui.`

>**Note**: you must need an wifi adapter which supports packet injection and monitor mode


**installation**

```
git clone https://github.com/akr3ch/wicker-gui
```
```
cd wicker-gui
```
```
sudo ./install.sh
```


>**Got an error?**: Feel free to submit your `Issues` in the issue tab of this repo:)
