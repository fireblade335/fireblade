# wifi-deauther-gui
This is a gui interface for airmon-ng 
And please keep in mind this is not the final product and till it's done i configured it to work more friendly with my own system, 
so u may need to change some stuff in code, 
but will definitely make it everyone friendly when everything is done :)
